def adder(*arg):
    return list(map(lambda x: x * x, arg))
adder(1, 2, 3)